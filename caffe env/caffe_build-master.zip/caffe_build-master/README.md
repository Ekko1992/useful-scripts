# caffe_build
shell script used for building caffe envoriment

aimed at ubuntu16.04LS + GTX1080 
