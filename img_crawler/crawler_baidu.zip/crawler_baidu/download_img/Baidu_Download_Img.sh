#!/bin/bash

##############################################################
# shell  script for download images
# author: Xingyu Wan
# 2017-04-12
##############################################################
#download img from Baidu
#$1 : keyword
#$2 : path of saving download images
#$3 : source code path

# step 1 
echo "Download images from Baidu for "$1
#echo "Phase A"
python3 "$3"/download_img/Baidu_Download_Img_A.py "$1" "$2"

# step 2  ## download images repeatedly
num=50
count_B=50
max_num_page_B=300
echo "Phase B"
while [ $num -le $max_num_page_B ]
do
python3 "$3"/download_img/Baidu_Download_Img_B.py "$1" "$2" -p $num
num=`expr $num + $count_B`
done
# step 3 end

#rm ""$2"/download_img/"$1".txt"




