#!/usr/bin/env python3
# coding=utf-8
import os, sys, urllib.request, re, threading, posixpath, urllib.parse, argparse, atexit, random, socket, time

##############################################################
# download images from Baidu (part A)
# author: Xingyu Wan
# 2017-04-12
##############################################################

pool_sema = threading.BoundedSemaphore(value = 8) #max number of download threads
socket.setdefaulttimeout(120)

in_progress = []
def download(url):
	pool_sema.acquire()
	path = urllib.parse.urlsplit(url).path
	filename = posixpath.basename(path)
	while os.path.exists(output_dir + '/' + filename): ## rename the fine if repeat
		filename = str(random.randint(0,100)) + filename
	in_progress.append(filename)
	try:
		urllib.request.urlretrieve(url, output_dir + '/' + filename) ## download img link
		in_progress.remove(filename) ## remove the task if finish
	except:
		print("FAIL " + filename) ## print to screen if failed
	pool_sema.release()

def removeNotFinished():
	for filename in in_progress:
		try:
			os.remove(output_dir + '/' + filename) ## clear the intermediate results when restart
		except FileNotFoundError:
			pass

if __name__ == "__main__":
	num_page = 500 #default maximum pages
	atexit.register(removeNotFinished)
	parser = argparse.ArgumentParser(description = 'Bing image bulk downloader')
	parser.add_argument('keyword', help = 'Keyword to search')
	parser.add_argument('default_path', help = 'output path')
	parser.add_argument('-o', '--output', help = 'Output directory', required = False)
	parser.add_argument('-p', '--page', help = 'Number of download pages', type = int, required = False)
	args = parser.parse_args()
	keyword = args.keyword
	keyword2 = keyword  #original keyword ,the same with shell script
	keyword = keyword.strip()
	path_save = args.default_path
	keyword_dir = keyword.replace('%27', '')
	keyword_dir = keyword_dir.replace('%20', '_')
	output_dir = path_save+'/download_img/'+keyword_dir #default output_dir
	if args.output:
		output_dir = args.output
	if args.page:
		num_page = args.page
	if not os.path.exists(output_dir):
		os.makedirs(output_dir)

	current = 2 ## start from page 2
	last = ''
	url_list=['abc']
	url_path=path_save+'/download_img/'+keyword_dir+'.txt'
	file2=open(url_path,'a') # save url link
	
	while True:
		socket.setdefaulttimeout(120)
		time.sleep(1)
		response = urllib.request.urlopen('https://image.baidu.com/search/flip?tn=baiduimage&ie=utf-8&word=' + str(keyword) + '&pn=' + str(current))
		html = response.read().decode('utf8')
		response.close()
		links_temp = re.findall('"objURL":"http:(.*?)"',html)
		links = []
		for i in links_temp:
			links.append('http:' + str(i))
		bingcount = len(links)
		if bingcount<1: 
			bingcount = 20 
		try:
			if links_temp[-1] == last:
				print("******links are empty ; break;************")
				break
			last = links_temp[-1]
			print('-------------------------------------------------------------')
			print(current)
			if current > num_page:
				print("*******out of setting num_page; break ;***********")
				break
			current += bingcount 
			for link in links:
				num = url_list.count(link)     
				if num > 0:
					continue
				url_list.append(link)
				file2.write(link)
				file2.write('\n')
				t = threading.Thread(target = download,args = (link,)) ## download with multi-threads
				t.start()
		except IndexError:
			print("No search results")
			sys.exit()
		time.sleep(0.2)
	file2.close()
